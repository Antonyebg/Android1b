package com.example.trabalho1b;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etEmail, etIdade, etNota1, etNota2, etDisciplina;
    private Button btEnviar, btLimpar;
    private TextView tvMensagem, tvInformacoes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Inicializando os elementos da UI
        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        etDisciplina = findViewById(R.id.etDisciplina);
        btEnviar = findViewById(R.id.btEnviar);
        btLimpar = findViewById(R.id.btLimpar);
        tvMensagem = findViewById(R.id.tvMensagem);
        tvInformacoes = findViewById(R.id.tvInformacoes);

        // Configurando o botão "Enviar"
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailDigitado = etEmail.getText().toString();
                String nomeDigitado = etNome.getText().toString();
                String idadeDigitado = etIdade.getText().toString();
                String nota1Digitado = etNota1.getText().toString();
                String nota2Digitado = etNota2.getText().toString();
                String disciplinaDigitado = etDisciplina.getText().toString();

                String mensagem = validateInputs(nomeDigitado, emailDigitado, idadeDigitado, nota1Digitado, nota2Digitado, disciplinaDigitado);
                tvMensagem.setText(mensagem.isEmpty() ? "Cadastro Efetuado" : mensagem);

                // Exibir informações se não houver erros
                if (mensagem.isEmpty()) {
                    // Calcula a média
                    double nota1 = Double.parseDouble(nota1Digitado);
                    double nota2 = Double.parseDouble(nota2Digitado);
                    double media = (nota1 + nota2) / 2;

                    // Verifica a situação
                    String status = media >= 60 ? "Aprovado" : "Reprovado";

                    String informacoes = "Nome: " + nomeDigitado + "\n" +
                            "Email: " + emailDigitado + "\n" +
                            "Idade: " + idadeDigitado + "\n" +
                            "Nota 1: " + nota1Digitado + "\n" +
                            "Nota 2: " + nota2Digitado + "\n" +
                            "Disciplina: " + disciplinaDigitado + "\n" +
                            "Média: " + String.format("%.2f", media) + "\n" +
                            "Status: " + status; // Exibe Aprovado/Reprovado

                    tvInformacoes.setText(informacoes);
                    tvInformacoes.setVisibility(View.VISIBLE); // Torna visível
                }
            }
        });

        // Configurando o botão "Limpar"
        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etNome.setText("");
                etEmail.setText("");
                etIdade.setText("");
                etNota1.setText("");
                etNota2.setText("");
                etDisciplina.setText("");
                tvMensagem.setText(""); // Limpa a mensagem
                tvInformacoes.setText(""); // Limpa as informações
                tvInformacoes.setVisibility(View.GONE); // Torna invisível
            }
        });

        // Configurando padding para a tela
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private String validateInputs(String nome, String email, String idade, String nota1, String nota2, String disciplina) {
        StringBuilder mensagem = new StringBuilder();
        if (nome.isEmpty()) mensagem.append("Por favor insira um Nome.\n");
        if (email.isEmpty() || !email.contains("@") || email.indexOf("@") <= 5) mensagem.append("Insira um email válido.\n");
        if (idade.isEmpty()) mensagem.append("Por favor insira sua Idade.\n");
        if (nota1.isEmpty()) mensagem.append("Por favor insira sua Nota 01.\n");
        if (nota2.isEmpty()) mensagem.append("Por favor insira sua Nota 02.\n");
        if (disciplina.isEmpty()) mensagem.append("Por favor insira uma Disciplina.\n");
        return mensagem.toString();
    }
}
